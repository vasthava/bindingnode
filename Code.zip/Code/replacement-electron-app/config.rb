
css_dir = "assets/css" # by Compass.app
sass_dir = "assets/sass" # by Compass.app
images_dir = "assets/css/images" # by Compass.app
output_style = :compressed # :expanded or :nested or :compact or :compressed
relative_assets = false # by Compass.app
line_comments = true # by Compass.app
sass_options = {:debug_info=>false} # by Compass.app
sourcemap = false # by Compass.app
